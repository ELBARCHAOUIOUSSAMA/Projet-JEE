package org.sid.ebankingbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbankingBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
